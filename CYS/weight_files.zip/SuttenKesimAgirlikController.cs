using System;
using Microsoft.AspNetCore.Mvc;
using CYS.Models;
using CYS.Repos;
using Microsoft.Extensions.Configuration;

namespace CYS.Controllers.WebApis
{
    [ApiController]
    [Route("api/[controller]")]
    public class SuttenKesimAgirlikController : ControllerBase
    {
        private readonly SuttenKesimAgirlikOlcumRepository _repository;
        private readonly HayvanCTX _hayvanCTX;

        public SuttenKesimAgirlikController(IConfiguration configuration)
        {
            _repository = new SuttenKesimAgirlikOlcumRepository(configuration);
            _hayvanCTX = new HayvanCTX();
        }

        [HttpPost]
        public IActionResult AddOlcum([FromBody] SuttenKesimAgirlikOlcum olcum)
        {
            try
            {
                olcum.olcumTarihi = DateTime.Now;
                if (olcum.kesimTarihi == DateTime.MinValue)
                {
                    olcum.kesimTarihi = DateTime.Now;
                }
                
                _repository.Add(olcum);
                
                // Hayvanın ağırlık bilgisini de güncelle
                if (olcum.hayvanId > 0)
                {
                    var hayvan = _hayvanCTX.hayvanTek("SELECT * FROM Hayvan WHERE id = @id", new { id = olcum.hayvanId });
                    if (hayvan != null)
                    {
                        hayvan.agirlik = olcum.agirlik.ToString();
                        _hayvanCTX.hayvanGuncelle(hayvan);
                    }
                }
                
                return Ok(new { success = true, message = "Sütten kesim ağırlığı başarıyla kaydedildi", data = olcum });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpGet("hayvan/{hayvanId}")]
        public IActionResult GetHayvanOlcumler(int hayvanId)
        {
            try
            {
                var olcumler = _repository.GetByHayvanId(hayvanId);
                return Ok(olcumler);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var olcum = _repository.GetById(id);
                if (olcum == null)
                {
                    return NotFound(new { message = "Sütten kesim ağırlık kaydı bulunamadı" });
                }
                return Ok(olcum);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var olcumler = _repository.GetAll();
                return Ok(olcumler);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("mobile/weight")]
        public IActionResult SaveMobileWeight([FromBody] MobileSuttenKesimWeight data)
        {
            try
            {
                var agirlikOlcum = new SuttenKesimAgirlikOlcum
                {
                    hayvanId = data.HayvanId > 0 ? data.HayvanId : 0,
                    agirlik = data.Weight,
                    kesimTarihi = data.KesimTarihi ?? DateTime.Now,
                    olcumTarihi = DateTime.Now,
                    bluetoothOlcum = true,
                    userId = data.UserId,
                    olcumNotu = data.Note,
                    requestId = data.RequestId,
                    agirlikOlcumu = data.Weight.ToString(),
                    anneRfid = data.AnneRfid,
                    kesimYasi = data.KesimYasi
                };

                _repository.Add(agirlikOlcum);
                
                // Hayvanın ağırlık bilgisini de güncelle
                if (data.HayvanId > 0)
                {
                    var hayvan = _hayvanCTX.hayvanTek("SELECT * FROM Hayvan WHERE id = @id", new { id = data.HayvanId });
                    if (hayvan != null)
                    {
                        hayvan.agirlik = data.Weight.ToString();
                        _hayvanCTX.hayvanGuncelle(hayvan);
                    }
                }
                
                return Ok(new { success = true, message = "Sütten kesim ağırlık verisi başarıyla kaydedildi", data = agirlikOlcum });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }
        
        [HttpPut("{id}")]
        public IActionResult UpdateOlcum(int id, [FromBody] SuttenKesimAgirlikOlcum olcum)
        {
            try
            {
                var existingOlcum = _repository.GetById(id);
                if (existingOlcum == null)
                {
                    return NotFound(new { message = "Sütten kesim ağırlık kaydı bulunamadı" });
                }
                
                olcum.id = id;
                _repository.Update(olcum);
                
                return Ok(new { success = true, message = "Sütten kesim ağırlık verisi başarıyla güncellendi", data = olcum });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }
    }

    // DTO for mobile weight data
    public class MobileSuttenKesimWeight
    {
        public double Weight { get; set; }
        public int HayvanId { get; set; }
        public int UserId { get; set; }
        public string? Note { get; set; }
        public string? RequestId { get; set; }
        public string? AnneRfid { get; set; }
        public int KesimYasi { get; set; }
        public DateTime? KesimTarihi { get; set; }
    }
} 